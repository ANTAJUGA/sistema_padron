# Twitter bootstrap 3 admin template

**I've never been a developer of this template.**
What I did once — I downloaded all the files from wrapbootstrap.com ace-admin demo-template and put everything on GitHub with minimal changes.

Actually, I uploaded to GitHub everything that **has already been in public** as demo-template.
Ace repository struck a chord and became popular on GitHub so I've been supporting the repository some time with new versions.

I wrote PHP-library to be able to download all the files from bootstrap-templates but library works not 100% and the code is too complicated to be shared in public.

I've never received any warnings from template authors that's why the repository is still here.
*No support here. Please, don't email me.*

## I`m not developer of this theme.
It`s only copy of <a href="http://wrapbootstrap.com/preview/WB0B30DGR">ace demo-template</a> from wrapbootstrap.
Repo contains minified ace js/css files.
You can read more about the license <a href="https://wrapbootstrap.com/theme/ace-responsive-admin-template-WB0B30DGR">here</a>.

see example http://ace.jeka.by/

Try:
- git clone git@github.com:bopoda/ace.git
- open ace/index.html in your desktop or mobile browser


Простой и многофункциональный Twitter bootstrap 3 шаблон для админки. Responsive дизайн.

Browsers:
- Internet Explorer 10
- Internet Explorer 11
- Internet Explorer 8
- Internet Explorer 9
- Latest Chrome
- Latest Firefox
- Latest Opera
- Latest Safari