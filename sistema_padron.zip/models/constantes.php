<?php 
class Constantes{
    const HORA_EC=5;
    const ESTADO_ACTIVO=1;
    const ESTADO_ELIMINADO=1;
    const TIPO_IDENTIFICACION=1;
    const SEXO=2;
    const GENERO=3;
    const ESTADO_CIVIL=4;
    const TIPO_SANGRE=5;
    const TIPO_DISCAPACIDAD=6;
    const TIPO_CARRERA=7;
    const TIPO_COLEGIO=8;
    const TIPO_MATRICULA=9;
    const PARALELO=10;
    const SI_NO=11;
    const SI_NO_NOAPLICA=12;
    const ESTUDIANTE_OCUPACION=13;
    const INGRESOS_ESTUDIANTE=14;
    const TIPO_INSTITUCION_PPP=15;
    const TIPO_BECA=16;
    const PRIMERA_RAZON_BECA=17;
    const SEGUNDA_RAZON_BECA=18;
    const TERCERA_RAZON_BECA=19;
    const CUARTA_RAZON_BECA=20;
    const QUINTA_RAZON_BECA=21;
    const SEXTA_RAZON_BECA=22;
    const TIPO_FINANCIAMIENTO_BECA=23;
    const ALCANCE_PROYECTO_VINCULACION=24;
    const NIVEL_FORMACION_PADRES=25;
    const SECTOR_ECONOMICO=26;
    const NUMERO_MATRICULA=27;

}
?>